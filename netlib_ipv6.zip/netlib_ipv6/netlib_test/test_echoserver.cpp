#include "test.h"
#include "BaseThread.h"
#include "Utils.h"
#include <sys/timeb.h>

struct send_data
{
	struct timeb tp;
	long index;
	char data_info[1000];
};

std::map<unsigned short, long> port_statis_map;
//STATIS_MAP port_statis;


extern char echo_server_addr[50];
extern unsigned short echo_server_port;
extern bool v6_mode;
unsigned int lost_pack_count = 0;

#if 0
class udp_peer : public IUdpEvent
{
public:
    udp_peer()
    {

    }
    virtual void OnRecvData(RawPacket* pack, unsigned int remote_ip, unsigned short remote_port)
    {
        /*char buf[1000] = { 0 };
        unsigned int ip;
        unsigned short port;*/
        //int len = udp_trans_->RecvData(buf, 1000, ip, port);
        //LogINFO("udp recv index:%d ,port:%d, rport:%d, len:%d", index_, port_, port, len);
    }
    virtual void OnNetError(int err_code)
    {

    }

    virtual RawPacket* GetMem(){ return &raw_packet_; };

    virtual void ReleaseMem(RawPacket* packet){}

    IUdpTrans* udp_trans_;
    unsigned short port_;
    int index_;
    RawPacket raw_packet_;
};
#endif
class udp_server : public udp_peer
{
public:
    udp_server(IUdpTransLib* udp_translib);

    void Start();

    virtual void OnRecvData(RawPacket* pack, unsigned int remote_ip, unsigned short remote_port);
	virtual void OnRecvData(RawPacket* pack, char * remote_ip, unsigned short remote_port);
    int recv_count_;
    uint64_t total_data_len_;

    static uint32_t ThreadFun(void* arg);
    void MyRun();
    CBaseThread thread_;
    IUdpTransLib* udp_translib_;
};

udp_server::udp_server(IUdpTransLib* udp_translib)
{
    recv_count_ = 0;
    total_data_len_ = 0;
    udp_translib_ = udp_translib;
}

void udp_server::OnRecvData(RawPacket* pack, unsigned int remote_ip, unsigned short remote_port)
{
	long recv_index_ = 0;
	if (pack->raw_packet_len_ == 0)
	{
        LogERR("udp server recv data len:%d", pack->raw_packet_len_);
	}

	std::map<unsigned short, long>::iterator it = port_statis_map.find(remote_port);

	if(it != port_statis_map.end())
	{
		recv_index_ = port_statis_map[remote_port];
	}
	else
	{
		port_statis_map[remote_port] = recv_index_;

	}

	struct send_data * recv_data = (struct send_data *)pack->raw_packet_;
	struct tm * tm;
	if (recv_data->index != recv_index_)
	{	
		struct tm * tm;
		tm = localtime(&(recv_data->tp.time));
		lost_pack_count ++;
		
		LogINFO("[*]recv pack error:%02d:%02d:%02d:%02d \
			send port [%d] recv [%d] expect [%d]",
		tm->tm_hour, tm->tm_min, tm->tm_sec, recv_data->tp.millitm,
		remote_port, recv_data->index, recv_index_);
		
		recv_index_ = recv_data->index;
	}
	recv_index_++;
	port_statis_map[remote_port] = recv_index_;
	
	struct send_data ser_senddata = {0};
	int ser_senddata_len = sizeof(struct send_data);
	ftime(&ser_senddata.tp);

	udp_trans_->SendData((char *)&ser_senddata, ser_senddata_len, remote_ip, remote_port);
	total_data_len_ += ser_senddata_len;	
	recv_count_++;


	//char buf[1000] = { 0 };
    //unsigned int ip;
    //unsigned short port;
    //int len = udp_trans_->RecvData(buf, 1000, ip, port);
 /*   
    if (pack->raw_packet_len_ > 0)
    {
        udp_trans_->SendData(pack->raw_packet_, pack->raw_packet_len_, remote_ip, remote_port);
        recv_count_++;
        total_data_len_ += pack->raw_packet_len_;
        //LogERR("udp server recv data count:%d", recv_count_);
    }
    else
    {
        LogERR("udp server recv data len:%d", pack->raw_packet_len_);
    }
 */   
}

void udp_server::OnRecvData(RawPacket* pack, char * remote_ip, unsigned short remote_port)
{
	long recv_index_ = 0;
	if (pack->raw_packet_len_ == 0)
	{
        LogERR("udp server recv data len:%d", pack->raw_packet_len_);
		return;
	}

	std::map<unsigned short, long>::iterator it = port_statis_map.find(remote_port);

	if(it != port_statis_map.end())
	{	
		recv_index_ = it->second;
	}

	struct send_data * recv_data = (struct send_data *)pack->raw_packet_;
	if (recv_data->index != recv_index_)
	{	
		lost_pack_count ++;
		struct tm * tm;
		tm = localtime(&(recv_data->tp.time));
		
		LogINFO("[*]recv pack error:%02d:%02d:%02d:%02d \
			send port [%d] recv [%d] expect [%d]",
		tm->tm_hour, tm->tm_min, tm->tm_sec, recv_data->tp.millitm,
		remote_port, recv_data->index, recv_index_);
		
		recv_index_ = recv_data->index;
	}

	recv_index_++;
	port_statis_map[remote_port] = recv_index_;
	
	struct send_data ser_senddata = {0};
	int ser_senddata_len = sizeof(struct send_data);
	ftime(&ser_senddata.tp);
/*
	if (0 != index_%200)
	{


	}	
*/	
	udp_trans_->SendData((char *)&ser_senddata, ser_senddata_len, remote_ip, remote_port);
	total_data_len_ += ser_senddata_len;	
	recv_count_++;






/*
//	LogINFO("recv len : %d", pack->raw_packet_len_);
	long recv_index_ = 0;
	if (pack->raw_packet_len_ == 0)
	{
        LogERR("udp server recv data len:%d", pack->raw_packet_len_);
		return;
	}

	std::map<unsigned short, long>::iterator it = port_statis_map.find(remote_port);

	if(it != port_statis_map.end())
	{	
		recv_index_ = it->second;
	}
	else
	{
		it->second = recv_index_;
	}

	struct send_data * recv_data = (struct send_data *)pack->raw_packet_;
	if (recv_data->index != recv_index_)
	{	
		lost_pack_count ++;
		struct tm * tm;
		tm = localtime(&(recv_data->tp.time));
		
		LogINFO("[*]recv pack error:%02d:%02d:%02d:%02d \
			send port [%d] recv [%d] expect [%d]",
		tm->tm_hour, tm->tm_min, tm->tm_sec, recv_data->tp.millitm,
		remote_port, recv_data->index, recv_index_);
		
		recv_index_ = recv_data->index;
	}
	recv_index_++;
	port_statis_map[remote_port] = recv_index_;
	
	struct send_data ser_senddata = {0};
	int ser_senddata_len = sizeof(struct send_data);
	ftime(&ser_senddata.tp);		
	udp_trans_->SendData((char *)&ser_senddata, ser_senddata_len, remote_ip, remote_port);
	total_data_len_ += ser_senddata_len;	
	recv_count_++;
*/
	
/*
    if (pack->raw_packet_len_ > 0)
    {
        udp_trans_->SendData(pack->raw_packet_, pack->raw_packet_len_, remote_ip, remote_port);
        recv_count_++;
        total_data_len_ += pack->raw_packet_len_;
        //LogERR("udp server recv data count:%d", recv_count_);
    }
    else
    {
        LogERR("udp server recv data len:%d", pack->raw_packet_len_);
    }
*/  

}

uint32_t udp_server::ThreadFun(void* arg)
{
    udp_server* server = (udp_server*)arg;
    server->MyRun();

    return 0;
}

void udp_server::MyRun()
{
    LogINFO("echo server set up");

    int threadid = -1;
    udp_trans_ = udp_translib_->CreateUdpSocket(threadid);
    udp_trans_->Init(this, echo_server_addr, echo_server_port, v6_mode);
    port_ = echo_server_port;
    index_ = -1;

    while (true)
    {
        Utils::Sleep(10 * 1000);
        LogINFO("Udp server recv:%d, total len:%d lost count:%d", recv_count_, total_data_len_, lost_pack_count);
    }
}	

void udp_server::Start()
{
    unsigned int thd = 0;
    thread_.BeginThread(ThreadFun, this, thd);
}

void test_udp_echoserver_send()
{

	system("echo 524288 > /proc/sys/net/core/rmem_max");
	system("echo 524288 > /proc/sys/net/core/wmem_max");


    IUdpTransLib* udp_translib = CreateUdpTransLib();
    udp_translib->Init(1, ASYNC_MODEL_EPOLL);
	udp_server *p = new udp_server(udp_translib);
	port_statis_map.clear();
    p->Start();

    getchar();
	delete p;
	udp_translib->Uninit();
}


