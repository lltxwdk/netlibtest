#include "test.h"
#include "BaseThread.h"
#include "Utils.h"
#include <sys/timeb.h>

struct send_data
{
	struct timeb tp;
	long index;
	char data_info[1000];
};

extern char echo_client_addr[50];
extern unsigned short echo_server_port;
extern bool v6_mode;
//int s_data_len = 500;
int s_max_count = 1 * 1000;
extern unsigned short s_max_client;
#define s_interval 10
static bool stopflag = false;

#if 0
class udp_peer : public IUdpEvent
{
public:
    udp_peer()
    {

    }
    virtual void OnRecvData(RawPacket* pack, unsigned int remote_ip, unsigned short remote_port)
    {
        /*char buf[1000] = { 0 };
        unsigned int ip;
        unsigned short port;
        int len = udp_trans_->RecvData(buf, 1000, ip, port);
        LogINFO("udp recv index:%d ,port:%d, rport:%d, len:%d", index_, port_, port, len);*/
    }
    virtual void OnNetError(int err_code)
    {

    }

    virtual RawPacket* GetMem() { return &raw_packet_; }

    //�ڴ�δʹ�ã��������ϲ㴦��
    virtual void ReleaseMem(RawPacket* packet) {}

    IUdpTrans* udp_trans_;
    unsigned short port_;
    int index_;
    RawPacket raw_packet_;
};
#endif

class udp_client : public udp_peer
{
public:
    udp_client();
    ~udp_client();
    void Start();
    bool IsSendOver();
    static uint32_t ThreadFun(void* arg);
    void MyRun();
    int send_max_count_;
    int recv_count_;

    virtual void OnRecvData(RawPacket* pack, unsigned int remote_ip, unsigned short remote_port);
    virtual void OnRecvData(RawPacket* pack, char * remote_ip, unsigned short remote_port);
	virtual long GetSendCout() {return send_count_;};
private:
    long send_count_;
    CBaseThread thread_;
};

udp_client::udp_client()
{
    send_count_ = 0;
    recv_count_ = 0;
}

udp_client::~udp_client()
{

}

void udp_client::Start()
{
    unsigned int thd = 0;
    thread_.BeginThread(ThreadFun, this, thd);
}

bool udp_client::IsSendOver()
{
    if (send_count_ >= send_max_count_)
    {
        return true;
    }

    return false;
}

uint32_t udp_client::ThreadFun(void* arg)
{
    udp_client* client = (udp_client*)arg;
    client->MyRun();

    return 0;
}

void udp_client::OnRecvData(RawPacket* pack, unsigned int remote_ip, unsigned short remote_port)
{
    recv_count_++;
}

void udp_client::OnRecvData(RawPacket* pack, char * remote_ip, unsigned short remote_port)
{
	recv_count_++;
}

void udp_client::MyRun()
{
	struct send_data buf;
	int send_data_len = sizeof(struct send_data);

    while (!stopflag)
	{
        Utils::Sleep(s_interval*5);

		memset(&buf, 0, send_data_len);
		ftime(&buf.tp);
		buf.index = send_count_;
        send_count_++;

//		LogINFO("get ip num %X, send port:%u", echo_client_addr, echo_server_port);

		if (v6_mode)
		{
			udp_trans_->SendData((char*)&buf, send_data_len, echo_client_addr, echo_server_port);
		}
		else
		{
			int ip = IPV4StrToInt(echo_client_addr);
			udp_trans_->SendData((char*)&buf, send_data_len, ip, echo_server_port);
		}
		
/*		
		if (send_count_ >= send_max_count_ )
		{
			break;
		}
*/		
    }

    LogINFO("Client send over, index:%d, count :%d", index_, send_count_);
}

void test_multithread_send()
{
    LogINFO("create client udp");

    IUdpTransLib* udp_translib = CreateUdpTransLib();
    udp_translib->Init(s_max_client, ASYNC_MODEL_EPOLL);

    udp_client udp_client_array[500];
    for (size_t i = 0; i < s_max_client; i++)
    {
        int threadid = -1;
        unsigned short port = 0;
        udp_client_array[i].udp_trans_ = udp_translib->CreateUdpSocket(threadid);
        udp_client_array[i].udp_trans_->Init(&udp_client_array[i], NULL, port, v6_mode);
        udp_client_array[i].port_ = port;
        udp_client_array[i].index_ = i;
        udp_client_array[i].send_max_count_ = s_max_count;

        LogINFO("create udp send index:%d ,port:%d", i, port);
    }
    LogINFO("enter to send");

    for (size_t i = 0; i < s_max_client; i++)
    {
        udp_client_array[i].Start();
    }
/*
    while (true)
    {
        bool send_over = true;
        LogINFO("Check send end..");
        Utils::Sleep(1000);
        for (size_t i = 0; i < s_max_client; i++)
        {
            if (!udp_client_array[i].IsSendOver())
            {
                send_over = false;
                continue;
            }

            LogINFO("Udp client recv data count:%d", udp_client_array[i].recv_count_);
        }

        if (send_over)
        {
            LogINFO("Udp send ok..");
            Utils::Sleep(10000);
            break;
        }
    }
*/

	getchar();
    LogINFO("set stop udp tran ...");

	stopflag = true;

    LogINFO("close udp");
    getchar();
	long unsigned udp_client_send_total = 0;
	for (size_t i = 0; i < s_max_client; i++)
	{
		udp_client_send_total += udp_client_array[i].GetSendCout();

	}
	LogINFO("udp total send :%ld", udp_client_send_total);	
	

    for (size_t i = 0; i < s_max_client; i++)
    {
        udp_client_array[i].udp_trans_->Close();
    }

    udp_translib->Uninit();

}


