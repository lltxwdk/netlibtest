#include "test.h"
#include <iostream>
#include "Utils.h"
#include <stdlib.h>

using namespace std;

unsigned int s_interval = 10;
unsigned int TEST_PEERS = 10;
unsigned short s_max_client = 1;


//ipv6 linklocal
//char echo_server_addr[50] = "fe80::173f:cb39:d5d3:145e%1";
//char echo_client_addr[50] = "fe80::173f:cb39:d5d3:145e";
bool v6_mode = true;

//ipv6 lo
/*
char echo_server_addr[50] = "::1";
char echo_client_addr[50] = "::1";
bool v6_mode = true;
*/

//char echo_server_addr[50] = "192.168.2.189";
char echo_server_addr[50] = {0};
char echo_client_addr[50] = {0};

unsigned short echo_server_port = 8900;

extern void test_tcp_client();
extern void test_tcp_server();



int main(int argc, char* argv[])
{
    TraceLog::GetInstance().OpenLog("netlib.log", TL_DEBUG, true);
    LogINFO("Test start\n");

    //test_normal(argc, argv);

	std::cout << "stdin :" << argc << endl;

	do
	{
		if (argc < 2 )
		{
			break;
		}

		if (argc >= 3)
		{
			TEST_PEERS = atoi(argv[2]);
			s_max_client = atoi(argv[2]);
		}

		std::cout << "TEST_PEERS:" << TEST_PEERS << endl;

		if ((argc >= 4) && (0 == strcmp(argv[3], "v4")))
		{
			v6_mode = false;
		}

		if (argc >= 5)
		{
			echo_server_port = atoi(argv[4]);
		}

		std::cout << "echo_server_port:" << echo_server_port << endl;


		if (v6_mode)
		{		
			strcpy(echo_server_addr, "fe80::173f:cb39:d5d3:145e%1");	
			strcpy(echo_client_addr, "fe80::173f:cb39:d5d3:145e");
		}
		else
		{
			strcpy(echo_server_addr, "192.168.2.189");	
			strcpy(echo_client_addr, "192.168.2.189");
		}
	
		if (0 == strcmp(argv[1], "tcpserver"))
		{	
			LogINFO("\nTest tcpserver!!");
			if (argc >= 5) 
			{
				strcpy(echo_server_addr, argv[4]);	
			}

			test_tcp_server();
		}
		else if (0 == strcmp(argv[1], "tcpclient"))
		{			
			LogINFO("\nTest tcpserver!!");
			if (argc >= 5) 
			{
				strcpy(echo_client_addr, argv[4]);
			}

			test_tcp_client();
		}
		else if (0 == strcmp(argv[1], "udpserver"))
		{
			LogINFO("\nTest udpserver!!");

			test_udp_echoserver_send();
		}
		else if (0 == strcmp(argv[1], "udpclient"))
		{
			LogINFO("\nTest udpclient!!");

			test_multithread_send();
		}
		else
		{
			break;
		}
		
	    LogINFO("\nTest over!!");	
		return 0;

	}while(0);
	
	test_normal(argc, argv);
	
	LogINFO("\nTest test_normal over!!");

	return 0;
}

