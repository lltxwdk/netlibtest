#include "UdpTrans.h"


UdpTrans::UdpTrans(EventLoop* ev_loop)
    :udp_sock_(this), ev_loop_(ev_loop)
{
}


UdpTrans::~UdpTrans()
{
}

bool UdpTrans::Init(IUdpEvent* ev_handler, char* local_ip, unsigned short& local_port, bool ipv6_mode)
{

	udp_sock_.SetIpv6(ipv6_mode);


	if (!udp_sock_.Init(local_ip, local_port))
    {
        return false;
    }

    if (!ev_loop_->AddEventFd(FD_UDP, &udp_sock_))
    {
        udp_sock_.Close();
        return false;
    }
    ev_handler_ = ev_handler;
    return true;
}

bool UdpTrans::SendData(char* data, int data_len,
    unsigned int remote_ip, unsigned short remote_port)
{
    return udp_sock_.SendData(data, data_len, remote_ip, remote_port);
}

bool UdpTrans::SendData(char* data, int data_len,
    const char* remote_ip, unsigned short remote_port)
{
    return udp_sock_.SendData(data, data_len, remote_ip, remote_port);
}


void UdpTrans::Close()
{
    ev_loop_->DelEventFd(&udp_sock_);
    udp_sock_.Close();
}
void UdpTrans::Release()
{
    delete this;
}
void UdpTrans::OnRecvData()
{
	struct sockaddr_storage remote;
	memset(&remote, 0, sizeof(remote));
	
	RawPacket* pack = ev_handler_->GetMem();

	int err_code = 0;	
	int result = udp_sock_.RecvData(pack->raw_packet_, sizeof(pack->raw_packet_), remote, err_code);
	if (0 > result)
	{
		ev_handler_->ReleaseMem(pack);
		ev_loop_->DelEventFd(&udp_sock_);
		ev_handler_->OnNetError(err_code);
		return;
	}
	if (0 == result)
	{
		ev_handler_->ReleaseMem(pack);
		return;
	}
	pack->raw_packet_len_ = result;


	if (udp_sock_.GetIsIpv6())
	{
		struct sockaddr_in6 *sin6 = (struct sockaddr_in6 *)&remote;	
		char src_ip[128] = { 0 };
		inet_ntop(AF_INET6, &sin6->sin6_addr, src_ip, 128);
		ev_handler_->OnRecvData(pack, src_ip, ntohs(sin6->sin6_port));
	}
	else
	{
		struct sockaddr_in *sin = (struct sockaddr_in *)&remote;		
		ev_handler_->OnRecvData(pack, sin->sin_addr.s_addr, ntohs(sin->sin_port));
	}
}

void UdpTrans::OnNetError(int err_code)
{
    ev_loop_->DelEventFd(&udp_sock_);
    ev_handler_->OnNetError(err_code);
}
